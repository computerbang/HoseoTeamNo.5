package com.main.caloriecalculator;

public class Controller {

    public void buttonClicked() {
    }
}

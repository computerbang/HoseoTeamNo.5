module com.main.caloriecalculator {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.main.caloriecalculator to javafx.fxml;
    exports com.main.caloriecalculator;
}
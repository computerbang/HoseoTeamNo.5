package com.main.caloriecalculator;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ApiCall {
                /// 1. 기본 URL 설정
                /// 'StringBuilder' 객체를 생성하고, API호출을 위한 기본 URL을 설정합니다.
                /// 'StringBuilder'는 문자열을 조작하기에 효율적인 클래스입니다.(가변객체이기 때문)
    private static String serviceKey = "nY9BAl1gzMofnhOR0y7cmt8ZXqnb2k9zZd%2FyFTqxi7x79dlrzBUNR9CDQfiZRM5s4c5Zw%2FseYWcUAKzskxGa8Q%3D%3D";
    private static StringBuilder urlBuilder;


    public static String nameAndCalorie(String keyword) {
        StringBuilder result = new StringBuilder();

        try {
                /// 2. 서비스 키 추가
            urlBuilder = new StringBuilder("http://apis.data.go.kr/1471000/FoodNtrIrdntInfoService1/getFoodNtrItdntList1");

                /// 'serviceKey'는 API인증을 위해 필요한 키입니다. 이미 인코딩된 상태로 제공됩니다. <?> 인코딩이 뭐지 </?>
                /// 'urlBuilder.append'를 사용하여 기본 URL뒤에 서비스 키를 추가합니다.
                /// 'URLEncoder.encode'메서드는 URL에 특수 문자가 포함될 경우 이를 인코딩해줍니다. 여기서는 '"serviceKey"'라는 문자열을 UTF-8로 인코딩하여 URL에 추가합니다.
                /// <?> 'URLEncode.ecnode'메서드는 URL에 특수문자가 포함될 경울 이를 인코딩한다는데...좀더 자세히 알고싶네.
                /// "serviceKey"라는 문자열에는 특수문자가 없는데 그래도 인코딩을 해야되는건가? </?>
            urlBuilder.append("?" + URLEncoder.encode("serviceKey", "UTF-8") + "=" + serviceKey);

                /// '&' 문자는 URL파라미터를 연결할 때 사용됩니다.
                /// <?> 위데 '?'문자는 시작할 때 쓰는 거랬지? 이게 Query인거고??? </?>
            urlBuilder.append("&" + URLEncoder.encode("desc_kor", "UTF-8") + "=" + URLEncoder.encode(keyword, "UTF-8"));

                /// "1"번 페이지의 항목 100개를 조회하기위한 코드
            urlBuilder.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8"));
            urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "=" + URLEncoder.encode("100", "UTF-8"));

                /// 'type'은 응답 데이터의 형식을 지정합니다.
                /// 여기서 JSON형식으로 응답받기 위해 '"json"'을 사용합니다.
                /// 'URLEncoder.encode'메서드를 사용하여 'type'과 '"json"'을 UTF-8로 인코딩합니다.
            urlBuilder.append("&" + URLEncoder.encode("type", "UTF-8") + "=" + URLEncoder.encode("json", "UTF-8"));



                /// 1. URL 객체 생성
                /// 'urlBuilder'객체에 의해 동적으로 생성된 URL문자열을 사용하여 'URL' 객체를 생성합니다.
                /// 'URL' 클래스는 인터넷 리소스의 주소를 나타내는 자바의 표준 클래스입니다.
            URL url = new URL(urlBuilder.toString());

                /// 2. HttpURLConnection 객체 생성
                /// 'url.openConnection()' 매서드를 호출하여 'HttpURLConnection' 객체를 생성합니다.
                /// 'HttpURLConnection' 클래스는 HTTP프로토콜을 사용하여 통신하기 위한 클래스입니다.
                /// <?> 'url.openConnection()' 매서드를 먼저 호출하고 'HttpURLConnection'객체를 만든다고? </?>
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                /// 3, 요청 메서드 설정
                /// 'setRequestMethod'메서드를 사용하여 HTTP요청 메서드를 설정합니다.
                /// 여기서는 데이터를 요청하는 GET메서드를 사용합니다.
                /// <?> setRequestMethod 메서드에 대해 자세히 물어보자 </?>
            conn.setRequestMethod("GET");

                /// 4. 요청 속성 성질
                /// 'setRequestProperty'메서드를 사용하여 HTTP 요청 헤더를 설정합니다.
                /// "Content-type"헤더를 "application/json"으로 설정하여 서버에 Json 형식의 응답을 요청합니다.
            conn.setRequestProperty("Content-type", "application/json");

                /// 5. 응답 코드 확인
                /// 'getResponseCode'메서드를 호출하여 서버로부터 받은 HTTP응답 코드르 확인합니다.
                /// 응답 코드는 요청의 성공 또는 실패를 나타내며, 일반적으로 200~299 범위는 성공, 400~499 범위는 클라이언트 오류, 500~ 599범위는 서버 오류를 의미합니다.
            int responseCode = conn.getResponseCode();

                /// 6. 응답 데이터읽기
                /// 응답 코드에 따라 입력 스트림을 결정합니다.
                /// - 응답 코드가 200 ~ 300 범위(성공)인 경우, 'conn.getInputStream()'을 사용하여 입력스트림을 생성합니다.
                /// - 그렇지 않은 경우(오류), 'conn.getErrorStream()'을 사용하여 오류 스트림을 생성합니다.
                /// <?> 입력스트림, 오류스트림이 어떤거지 </?>
                /// 'BufferedReader'를 사용하여 입력 스트림을 읽습니다 'BufferReader'는 효율적으로 문자를 읽기 위해 사용됩니다.
            BufferedReader rd;
            if (responseCode >= 200 && responseCode <= 300) {
                rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                System.out.println("rd = " + rd);
            } else {
                rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            }

                /// 7. 응답 데이터를 문자열로 변환
                /// 'BufferedReader'를 사용하여 응답 데이터를 한 줄씩 읽어옵니다.
                /// 읽어온 데이터를 'StringBuilder'에 추가하여 전체 응답을 하나의 문자열로 만듭니다.
                /// 모든 데이터를 읽은 후 'BufferedReader'를 닫고, 'HttpRULConnection' 객체를 해제합니다.
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            System.out.println("sb = " + sb);
            rd.close();
            conn.disconnect();
            String response = sb.toString();
            System.out.println("response = " + response);




                /// 1. JSON파싱
                /// 'JSONParser'객체를 생성합니다.
                /// 'parser.parse(response)'를 사용하여 JSON문자열('response')을 파싱합니다.
                /// 파싱된 결과는 'JSONObject'로 반환됩니다.
                /// <?> 만약 XML로 파싱했으면 'response'는 XML문자열로 되는거였을까? </?>
            JSONParser parser = new JSONParser();
            JSONObject jsonObject = (JSONObject) parser.parse(response);
            System.out.println("jsonObject = " + jsonObject);

                /// 2. JSON 구조 탐색
                /// 최상위 JSON객체('jsonObject')에서 "body"라는 키를 가진 객체를 가져옵니다.
                /// JSON구조에서 'body'키가 포함된 객체를 'JSONObect'로 반환합니다.
                /// <?> 'JsonObject'에 "body"라는 키 같은게 여러개 저장되있는건가?
                /// JSON에 대해 아는게 없으니깐 뭔 소린지 이해가 안되네. "body"에 내가 원하는 값이 있는건가. </?>
            JSONObject body = (JSONObject) jsonObject.get("body");

                /// 3. 데이터 추출
                /// 'body'객체가 'null'이 아닌지 확인합니다.
                /// 'body'객체에서 '"items"'키를 가진 배열을 가져옵니다. 이는 'JSONArray'로 반환됩니다.
            if (body != null) {
                JSONArray items = (JSONArray) body.get("items");
                System.out.println("items = " + items);

                /// 데이터 처리 및 결과 생성
                /// 4. 아이템 반복 처리
                /// 'items'배열을 반복하면서 각 아이템을 처리합니다.
                /// 각 아이템('item')은 'JSONObject'로 변환됩니다.
                /// 'descKor'키를 사용하여 식품이름을 가져오고, 'nutrCont1'키를 사용하여 칼로리 정보를 가져옵니다.
                /// 'nutrCont1'값은 'String' 형태로 되어있으므로 'double'로 변환합니다.
                /// 식품이름('descKor')이 주어진 키워드('keyword')를 포함하는지 확인합니다.
                /// 'foodCaloriesMap'에 식품 이름과 칼로리 정보를 저장합니다. 이미 존재하는 식품 이름인 경우, 기존 칼로리 정보보다 큰 값을 저장합니다.
                HashMap<String, Double> foodCaloriesMap = new HashMap<>();
                for (Object item : items) {
                    JSONObject itemObject = (JSONObject) item;
                    String descKor = (String) itemObject.get("DESC_KOR");
                    Integer bgnYear = Integer.valueOf((String) itemObject.get("BGN_YEAR"));
                    Double nutrCont1 = Double.valueOf((String) itemObject.get("NUTR_CONT1"));
                    if (descKor.contains(keyword)) {
                        if (!foodCaloriesMap.containsKey(descKor) || foodCaloriesMap.get(descKor) < nutrCont1) {
                            foodCaloriesMap.put(descKor, nutrCont1);
                        }
                    }
                }

                /// 5. 결과 문자열 생성
                /// 'foodCaloriesMap'에 저장된 각 항목을 반복하면서 결과 문자열을 생성합니다.
                /// 'result' 문자열에 식품 이름과 칼로리 정보를 추가합니다.
                /// 'body' 객체가 'null'인 경우, "No data found." 메시지를 추가합니다.
                for (Map.Entry<String, Double> entry : foodCaloriesMap.entrySet()) {
                    result.append("Food Name: ").append(entry.getKey()).append("\n");
                    result.append("Calories: ").append(entry.getValue()).append("\n");
                }
            } else {
                result.append("No data found.\n");
            }

                /// 예외 처리
                /// 6. 예외처리
                /// 'try'블록 내에서 발생할 수 있는 'IOException'및 'ParseException'을 처리합니다
                /// 예외가 발생하면 스택 추적을 출력하고, 결과 문자열에 오류 메시지를 추가합니다.
        } catch (IOException | ParseException e) {
            e.printStackTrace();
            result.append("An error occurred: ").append(e.getMessage()).append("\n");
        }

        System.out.println("result = " + result.toString());
        return result.toString();
    }
}
package com.main.caloriecalculator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class Controller {

    /// 왼쪽 레이아웃 Control들
    @FXML
    private TextField first_1_textField;
    @FXML
    private ListView<String> first_1_listView;
    @FXML
    private Button first_1_button;
    @FXML
    private Button first_ReadMore_button;
    @FXML
    private Button first_confirm_button;

    /// 두번째 레이아웃 Control들
    @FXML
    private ListView<String> second_showFoodsIAte_listview;
    @FXML
    private Button second_delete_button;
    @FXML
    private TextArea second_showAllFoods_textArea;

    /// 세번째 레이아웃 Controls들 은 지혜씨한테 받으면 하는걸로


    public void pressEnterInTextField() {
        first_1_textField.setOnAction(e -> {
            first_1_button.fire();
        });
    }

    private ObservableList<String> ov = FXCollections.observableArrayList();
    public void confirmButtonMethod() {

        second_showFoodsIAte_listview.setItems(ov);

        String name = first_1_listView.getSelectionModel().getSelectedItem();
        ov.add(name);
    }

    @FXML
    public void buttonClicked() {
        String input = first_1_textField.getText();
        if (!input.isEmpty()) {
            String result = ApiCall.nameAndCalorie(input);
            updateListView(result);
            first_1_textField.clear();
        }
    }

    private void updateListView(String apiResult) {
        ObservableList<String> items = FXCollections.observableArrayList();
        String[] lines = apiResult.split("\n");

        System.out.println("");
        System.out.println(lines[0]);
        System.out.println(lines[1]);
        System.out.println(lines[2]);
        System.out.println(lines[3]);
        System.out.println("");

        for (int i = 0; i < lines.length; i += 2) {
            if (i + 1 < lines.length) {
                String foodName = lines[i].replace("Food Name: ", "");
                String calories = lines[i + 1].replace("Calories: ", "");
                items.add(foodName + " - " + calories + " kcal");
            }
        }
        first_1_listView.setItems(items);
    }
}
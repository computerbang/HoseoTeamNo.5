module com.main.caloriecalculator {
    requires javafx.controls;
    requires javafx.fxml;
    requires json.simple;


    opens com.main.caloriecalculator to javafx.fxml;
    exports com.main.caloriecalculator;
}
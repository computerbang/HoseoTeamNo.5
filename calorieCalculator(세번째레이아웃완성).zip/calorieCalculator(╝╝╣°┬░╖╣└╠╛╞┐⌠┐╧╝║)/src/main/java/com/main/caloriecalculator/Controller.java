package com.main.caloriecalculator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class Controller {

    /// 왼쪽 레이아웃 Control들
    @FXML
    private TextField first_1_textField;
    @FXML
    private ListView<String> first_1_listView;
    @FXML
    private Button first_1_button;
    @FXML
    private Button first_ReadMore_button;
    @FXML
    private Button first_confirm_button;

    /// 두번째 레이아웃 Control들
    @FXML
    private ListView<String> second_showFoodsIAte_listview;
    @FXML
    private Button second_delete_button;
    @FXML
    private TextArea second_showAllFoods_textArea;

    /// 세번째 레이아웃 Controls들 은 지혜씨한테 받으면 하는걸로
    @FXML
    private ChoiceBox<String> choice_gender;
    @FXML
    private ComboBox<Integer> choice_age;
    private ObservableList<String> ov = FXCollections.observableArrayList();

    private ObservableList<String> secondListViewOv = FXCollections.observableArrayList();
    private double sumCalorie;

    @FXML
    private TextField heightTextField;
    @FXML
    private TextField weightTextField;
    @FXML
    private Button compareButton;
    @FXML
    private TextArea resultTextArea;
    @FXML
    private Slider calorieSlider;

    @FXML
    public void initialize() {
        sumCalorie = 0;
        choice_gender.setItems(FXCollections.observableArrayList("남성", "여성"));
        choice_gender.setValue("남성");

        ObservableList<Integer> ageList = FXCollections.observableArrayList();
        for (int i = 0; i <= 100; i++) {
            ageList.add(i);
        }
        choice_age.setItems(ageList);
        choice_age.setPromptText("나이");

        second_showFoodsIAte_listview.setItems(secondListViewOv);
        second_delete_button.setOnAction(e -> pressDeleteButton());

        calorieSlider.setMin(0);
    }

    public void pressEnterInTextField() {
        first_1_textField.setOnAction(e -> {
            first_1_button.fire();
            first_1_textField.requestFocus();
        });
    }

    public void pressDeleteButton() {
        String name = second_showFoodsIAte_listview.getSelectionModel().getSelectedItem();

        double calories = extractNumbers(name);
        sumCalorie -= calories;
        System.out.println("sumCalorie = " + sumCalorie);

        secondListViewOv.remove(name);
        ov.remove(name);

        updateCaloriesSlider();
    }

    public void confirmButtonMethod() {
        String name = first_1_listView.getSelectionModel().getSelectedItem();
        if (name != null && !ov.contains(name)) {
            ov.add(name);
            if (!secondListViewOv.contains(name)) {
                double calories = extractNumbers(name);
                sumCalorie += calories;
                System.out.println("sumCalorie = " + sumCalorie);
                secondListViewOv.add(name);
            }
        }

        updateCaloriesSlider();
    }

    @FXML
    public void buttonClicked() {
        try {
            String input = first_1_textField.getText();
            if (!input.isEmpty()) {
                String result = ApiCall.nameAndCalorie(input);
                updateListView(result);
                first_1_textField.clear();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateListView(String apiResult) {
        ObservableList<String> items = FXCollections.observableArrayList();
        String[] lines = apiResult.split("\n");

        System.out.println("");
        System.out.println(lines[0]);
        System.out.println(lines[1]);
        System.out.println(lines[2]);
        System.out.println(lines[3]);
        System.out.println("");

        for (int i = 0; i < lines.length; i += 2) {
            if (i + 1 < lines.length) {
                String foodName = lines[i].replace("Food Name: ", "");
                String calories = lines[i + 1].replace("Calories: ", "");
                items.add(foodName + " - " + calories + " kcal");
            }
        }
        first_1_listView.setItems(items);
    }

    private double extractNumbers(String input) {
        double result = 0;
        String onlyDigits = input.replaceAll("[^0-9.]", "");

        if (!onlyDigits.isEmpty()) {
            try {
                result = Double.parseDouble(onlyDigits);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    @FXML
    private void compareCalories() {
        String gender = choice_gender.getValue();
        int age = (int) choice_age.getValue();
        double height = Double.parseDouble(heightTextField.getText().trim());
        double weight = Double.parseDouble(weightTextField.getText().trim());

        double consumedCalories = sumCalorie;
        double recommendedCalories = calculateRecommendedCalories(gender, age, height, weight);
        double difference = consumedCalories - recommendedCalories;

        String message;
        if (difference > 0) {
            message = String.format("당신의 적정 칼로리는 %.2f kcal 이고, 적정 칼로리보다 %,.2f kcal 더 섭취했습니다.", recommendedCalories, difference);
        } else if (difference < 0) {
            message = String.format("당신의 적정 칼로리는 %.2f kcal 이고, 적정 칼로리보다 %,.2f kcal 덜 섭취했습니다.", recommendedCalories, Math.abs(difference));
        } else {
            message = "당신의 적정 칼로리 " + recommendedCalories + "kcal 섭취했습니다.";
        }

        resultTextArea.setWrapText(true);
        resultTextArea.setText(message);

        updateCaloriesSlider();
    }

    private double calculateRecommendedCalories(String gender, int age, double height, double weight) {
        // BMR 계산식
        double bmr;
        if (gender.equals("남성")) {
            bmr = 66.47 + (13.75 * weight) + (5 * height) - (6.76 * age);
        } else {
            bmr = 655.1 + (9.56 * weight) + (1.85 * height) - (4.68 * age);
        }
        return bmr;
    }

    private void updateCaloriesSlider() {
        double recommendedCalories = calculateRecommendedCalories(choice_gender.getValue(), choice_age.getValue(), Double.parseDouble(heightTextField.getText().trim()), Double.parseDouble(weightTextField.getText().trim()));
        calorieSlider.setMax(sumCalorie > recommendedCalories ? sumCalorie : recommendedCalories);
        calorieSlider.setValue(sumCalorie);
    }
}

package com.main.caloriecalculator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.util.List;

public class Controller {

    @FXML
    TextField textField;
    @FXML
    ListView<String> listView;
    @FXML
    Button



    public void buttonClicked() {
        String input = textField.getText();

        ObservableList<String> items = FXCollections.observableArrayList();

        if (!input.isEmpty()) {
            listView.setItems(items);
            items.add(input);
            textField.clear();
        }


    }



}
